import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class ServerThread extends Thread {
	Socket sock;	              // Socket connected to the Client
	PrintWriter writeSock;        // Used to write data to socket
	PrintWriter logfile;
	BufferedReader readSock;

	// Constructor
	public ServerThread(Socket s, PrintWriter logfiles) {
	    try {
	    	this.sock = s;
			this.logfile = logfiles;
			writeSock = new PrintWriter(sock.getOutputStream(), true);
			readSock = new BufferedReader( new InputStreamReader(
		            sock.getInputStream() ) );
		} catch (IOException e6) {
			logfile.println(e6.toString());
		}
	}
	
	// run() method that is called by start() from Server class
	public void run() {
		boolean quitTime = true;
	    while( quitTime )
	    {
	       String inLine = null;
		   try {
				inLine = readSock.readLine();
				CeaserCipher encrypt = new CeaserCipher();
				
				if( inLine.equals("quit")) {
					quitTime = false;
			        writeSock.println("Good Bye!\n");
				    this.sock.close();
				} else {
					// returning the encrypted string from CeaserCipher class
					String outLine = encrypt.encrypt(inLine) ;
				    writeSock.println( outLine );
			    } 
		   } catch (IOException e4) {
			   logfile.println(e4.toString());
	       }  
	    }	
	    try {
			this.sock.close();
			logfile.println("Connection closed. Port: 5520");
		} catch (IOException e) {
			logfile.println(e.toString());
		}
	    
	    logfile.close();
	}

}
