import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	// Default values
	String hostname = "localhost";
	int port = 5520;
	int c = 1;
	
	public void run() {

		PrintWriter pw = null;      
		try {
			// it creates a file if id doesn't exist or append to it if exists
		    pw = new PrintWriter(new FileWriter("prog1b.log"), true); 
		}  catch ( IOException e1 ) {
			// appending errors in the file
			pw.println(e1.toString());
		}
		
		// Getting date in right format as required
	    java.util.Date date = new java.util.Date();  
	    
		try {
			ServerSocket servSock = new ServerSocket( port );
			while( true )
		    {
				// accepting multiple connections (MultiThreading)
				Socket sock = servSock.accept();
				ServerThread servThread = new ServerThread( sock, pw );
				servThread.start();
				c++;
				if(c%2 == 0) {
					pw.println("Got a connection: " + date + " /127.0.0.1 Port: 5520");
				} else {
					pw.println("Connection closed. Port: 5520");
				}
		    }
		} catch (IOException e) {
			pw.println(e.toString());
		}
		
		// closing file after it is done writing
		pw.close();
	}
		
	public static void main(String[] args) throws IOException {
		// System.out.println("Server is running ...");
	    Server server = new Server();
	    server.run();
	}
}














