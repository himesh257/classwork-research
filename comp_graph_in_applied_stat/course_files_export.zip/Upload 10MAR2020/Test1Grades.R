#Test 1 Grades
library(faraway)
library(psych)
library(ggplot2)

#read in the test grades which are in a csv file
Test1 <- read.csv("C:/Users/jmard/Desktop/Computing and Graphics in Applied Statistics2020/Test1GradesDisplay.csv",header = TRUE)
Test1
describe(Test1)

windows(7,7)
#save graphics output in a pdf file

pdf(file="C:/users/jmard/Desktop/Computing and Graphics in Applied Statistics2020/Test1Grades_out.pdf")
hist(Test1$Test1Grade,xlab="Test 1 Grade",main="Test 1 Grade Distribution")

stem(Test1$Test1Grade)

dev.off()
